// Isolated diagnostic candidate. Final delivery should bake accepted normals offline.
export const HARDWARE_NORMAL_REVISION='analytic-azimuth-preserve-profile-r02';
const metadata=await(await fetch(new URL('./normal-data.json',import.meta.url))).json();
const compressed=await fetch(new URL('./normal-data.bin.gz',import.meta.url));
if(!compressed.ok)throw new Error('Hardware normal fixture fetch failed');
const data=await new Response(compressed.body.pipeThrough(new DecompressionStream('gzip'))).arrayBuffer();
function fingerprint(array){let hash=2166136261;for(const v of new Uint8Array(array.buffer,array.byteOffset,array.byteLength))hash=Math.imul(hash^v,16777619)>>>0;return hash.toString(16).padStart(8,'0');}
export function repairHardwareCurvatureNormals(source){
 const applied=[],skipped=[],originals=[];
 for(const row of metadata){
  const mesh=source.find(m=>m.userData.sourceIndex===row.sourceIndex),g=mesh?.geometry,p=g?.attributes.position,n=g?.attributes.normal,index=g?.index;
  if(!p||!n||!index||p.isInterleavedBufferAttribute||n.isInterleavedBufferAttribute||p.count!==row.positionCount||n.count!==p.count||index.count!==row.indexCount||fingerprint(p.array)!==row.positionFNV32||fingerprint(index.array)!==row.indexFNV32){skipped.push({sourceIndex:row.sourceIndex,reason:'source fixture mismatch'});continue;}
  const ids=new Uint32Array(data,row.byteOffset,row.count),values=new Float32Array(data,row.byteOffset+row.count*4,row.count*3),copy=n.clone();
  for(let k=0;k<ids.length;k++){
   const i=ids[k];if(i>=n.count)throw new Error('Hardware normal index out of range');
   // Preserve actual current axial/profile normal, including pre-existing repairs.
   const y=n.getY(i),radial=Math.sqrt(Math.max(0,1-y*y)),x=values[k*3],z=values[k*3+2],length=Math.hypot(x,z);
   if(length<1e-12)continue;
   copy.setXYZ(i,x/length*radial,y,z/length*radial);
  }
  copy.needsUpdate=true;g.setAttribute('normal',copy);originals.push({geometry:g,normal:n});applied.push({sourceIndex:row.sourceIndex,vertices:row.count});
 }
 return{revision:HARDWARE_NORMAL_REVISION,applied,skipped,totalChangedVertices:applied.reduce((n,r)=>n+r.vertices,0),restore(){for(const{geometry,normal}of originals){geometry.dispose();geometry.setAttribute('normal',normal);}originals.length=0;}};
}
