// Private numerical contact-path candidate, not production or physical dynamics.
export const detour=Object.freeze({start:.2691515628123496,end:.26915308961530293,center:.104,halfWidth:.035,peakDegrees:.002});
export function forkContactDetourDegrees(fraction){
 if(!Number.isFinite(fraction))throw new TypeError('Finite source-cycle fraction required');
 const u=(fraction-detour.start)/(detour.end-detour.start),q=(u-detour.center)/detour.halfWidth;
 return Math.abs(q)<1?detour.peakDegrees*Math.cos(Math.PI*q/2)**2:0;
}
export const CONTACT_DETOUR_PROVENANCE=Object.freeze({revision:'fork-contact-detour-private-v1',kind:'numerical kinematic path correction',testedAssemblySha256:'04335bab9e05f1610984ceeee355a80e06277ed1f3d7980355a9f8a2146fe6bf',nativeGeometryModified:false,sourceSha256:'40aadf5b8e6ed73fa0553b46873f68438d023674035b0bffb04afba569f31e99',affectedSourceIndices:Object.freeze([111,112,113,114,115]),testedPairs:Object.freeze([[99,114],[99,115],[111,136],[112,135],[111,135]].map(Object.freeze)),finitePairSections:135980,numericalThresholdMM:1e-6,scope:'Five selected pairs, finite source-cycle phase/depth sections; not continuous 3D clearance, all tooth identities, fixed neighbors, dynamics or manufacturing validation',browserValidated:false});
