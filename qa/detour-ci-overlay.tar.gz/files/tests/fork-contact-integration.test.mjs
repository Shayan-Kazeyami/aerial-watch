import {fileURLToPath} from 'node:url';
import {test} from 'node:test';import assert from 'node:assert/strict';import crypto from 'node:crypto';
import {forkContactDetourDegrees as detour,detour as D} from '../assembly-fork-contact-detour.js';
import fs from 'node:fs';
const repo=fileURLToPath(new URL('../',import.meta.url)).replace(/\/$/,'');const T=await import(repo+'/vendor/three.module.js');const {createAssemblyMotion}=await import(repo+'/assembly-motion.js');const {createAssemblyEscapement:baselineFactory}=await import('./fixtures/escapement-before-detour.mjs');
const {createAssemblyEscapement:candidateFactory}=await import('../assembly-escapement.js');
const b=fs.readFileSync(repo+'/rebuild/assembly.glb'),n=b.readUInt32LE(12),g=JSON.parse(b.subarray(20,20+n)),off=28+n;
function attr(i){const a=g.accessors[i],v=g.bufferViews[a.bufferView],k={VEC3:3,VEC4:4,SCALAR:1}[a.type],out=new Float32Array(a.count*k);for(let j=0;j<a.count;j++)for(let c=0;c<k;c++)out[j*k+c]=b.readFloatLE(off+(v.byteOffset||0)+(a.byteOffset||0)+j*(v.byteStride||k*4)+c*4);return new T.BufferAttribute(out,k)}
const root=new T.Group(),source=[];for(const no of g.nodes){if(no.extras?.sourceIndex===undefined)continue;const p=g.meshes[no.mesh].primitives[0],geometry=new T.BufferGeometry();geometry.setAttribute('position',attr(p.attributes.POSITION));geometry.setAttribute('normal',attr(p.attributes.NORMAL));const a=g.accessors[p.indices],v=g.bufferViews[a.bufferView],s=a.componentType===5125?4:2,ix=[];for(let j=0;j<a.count;j++)ix.push(s===4?b.readUInt32LE(off+(v.byteOffset||0)+(a.byteOffset||0)+j*s):b.readUInt16LE(off+(v.byteOffset||0)+(a.byteOffset||0)+j*s));geometry.setIndex(ix);const mesh=new T.Mesh(geometry);mesh.name=no.name;mesh.userData=no.extras;mesh.position.fromArray(no.translation);if(no.rotation)mesh.quaternion.fromArray(no.rotation);root.add(mesh);source.push(mesh)}

const motion=createAssemblyMotion(source,JSON.parse(fs.readFileSync(repo+'/assets/manual-a-parts.json')));
const baseline=baselineFactory(motion),candidate=candidateFactory(motion);
const snapshot=()=>new Map(source.map(m=>[m.userData.sourceIndex,[...m.position.toArray(),...m.quaternion.toArray()]]));
const difference=(a,b)=>Math.max(...a.map((v,i)=>Math.abs(v-b[i])));
const original=snapshot(),originalGeometry=new Map(source.map(m=>[m.userData.sourceIndex,m.geometry]));
const geometryHash=()=>{const h=crypto.createHash('sha256');for(const m of source)for(const a of Object.values(m.geometry.attributes))h.update(Buffer.from(a.array.buffer,a.array.byteOffset,a.array.byteLength));return h.digest('hex');};
const originalHash=geometryHash();
test('actual private runtime applies coherent five-part fork correction only',()=>{
 const t=.269151721094/3.5;const bs=baseline.apply(t),before=snapshot(),cs=candidate.apply(t),after=snapshot();
 assert(cs.alpha>bs.alpha);assert(Math.abs(cs.alpha-bs.alpha-detour(bs.fraction))<1e-12);
 for(const key of Object.keys(bs))if(key!=='alpha')assert.equal(cs[key],bs[key],key);
 for(const [id,a] of before){const delta=difference(a,after.get(id));if([111,112,113,114,115].includes(id))assert(delta>1e-9,'fork '+id);else assert(delta<1e-12,'unrelated '+id);}
 for(const e of motion.entries.filter(e=>[111,112,113,114,115].includes(e.mesh.userData.sourceIndex))){const id=e.mesh.userData.sourceIndex,v=before.get(id),q=new T.Quaternion().setFromAxisAngle(new T.Vector3(0,1,0),detour(bs.fraction)*Math.PI/180),p=new T.Vector3(...v.slice(0,3)).sub(e.pivot).applyQuaternion(q).add(e.pivot),orientation=q.clone().multiply(new T.Quaternion(...v.slice(3)));assert(difference([...p.toArray(),...orientation.toArray()],after.get(id))<1e-12,'common native pivot '+id);}
 assert.deepEqual(candidate.contactDetour.affectedSourceIndices,[111,112,113,114,115]);assert.equal(candidate.contactDetour.finitePairSections,135980);assert.equal(candidate.contactDetour.browserValidated,false);
});
test('outside support exact sampler identity and pose identity over signed cycles',()=>{
 const phases=[0,.1,.25,.26915,.26916,.5,.75,.99];
 for(const cycle of [-2,-1,0,1,2])for(const phase of phases){const t=(cycle+phase)/3.5;assert.deepEqual(candidate.sample(t),baseline.sample(t));baseline.apply(t);const a=snapshot();candidate.apply(t);const b=snapshot();for(const [id,p]of a)assert(difference(p,b.get(id))<1e-12,'outside '+id);}
});
test('arbitrary reversal/seeks deterministic, no accumulated correction',()=>{
 const times=[.269151721094/3.5,.1,.269151721094/3.5,-.730848278906/3.5,0,.269151721094/3.5];const expected=new Map();
 for(const t of times){candidate.apply(t);const snap=snapshot();if(expected.has(t)){for(const [id,p]of snap)assert(difference(p,expected.get(t).get(id))<1e-12);}else expected.set(t,snap);}
 for(const t of [...times].reverse()){candidate.apply(t);for(const [id,p]of snapshot())assert(difference(p,expected.get(t).get(id))<1e-12);}
});
test('support endpoints and cycle wrap retain baseline continuity',()=>{
 for(const u of [D.center-D.halfWidth,D.center+D.halfWidth]){const f=D.start+(D.end-D.start)*u;assert(Math.abs(detour(f))<1e-18);for(const e of [-1e-10,0,1e-10]){const b=baseline.sample((f+e)/3.5),c=candidate.sample((f+e)/3.5);assert(Math.abs(c.alpha-b.alpha)<1e-7);}}
 for(const t of [-1e-10,0,1e-10,1/3.5-1e-10,1/3.5,1/3.5+1e-10])assert.deepEqual(candidate.sample(t),baseline.sample(t));
});
test('reset and dispose restore source pose and buffers, repeat construction safe',()=>{
 candidate.reset();for(const [id,p]of snapshot())assert(difference(p,original.get(id))<1e-12);for(const m of source)assert.equal(m.geometry,originalGeometry.get(m.userData.sourceIndex));assert.equal(geometryHash(),originalHash);
 candidate.apply(.269151721094/3.5);candidate.dispose();assert.equal(geometryHash(),originalHash);for(const [id,p]of snapshot())assert(difference(p,original.get(id))<1e-12);assert.throws(()=>candidate.sample(0));
 baseline.dispose();const fresh=candidateFactory(motion);assert.equal(fresh.sample(0).alpha,baselineFactory(motion).sample(0).alpha);fresh.dispose();
});
