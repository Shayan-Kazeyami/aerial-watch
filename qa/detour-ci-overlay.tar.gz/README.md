# Compact private detour overlay for frozen cap v2

No upload, source mutation or publication performed. Read-only applicability check passes against current frozen cap v2:8 source/asset/tool SHA256 checks plus modified-source and manifest identities. Exact values in overlay-manifest.json. Payload135,731 bytes before metadata; no models, textures, browser traces or full source clone.

## Exact patch scope

Deployable changes (3 files):
- assembly-escapement.js: import bounded helper; add its delta to sampled fork alpha, leaving train time/wheel/balance unchanged; expose finite-scope provenance. Existing apply/angleFor(pallet) handles all111–115 at native pivots.
- assembly-fork-contact-detour.js: new C1 .002-degree narrow first-drop helper and bounded evidence metadata. No geometry edits or retiming.
- assembly-review.js: saved-view escapement revision becomes r09-contact-detour-private-v1 and records contactDetour metadata.

QA-only additions (2 files):
- tests/fork-contact-integration.test.mjs: portable actual166-source-mesh test, no cloud absolute paths.
- tests/fixtures/escapement-before-detour.mjs: original frozen module with only dependency import paths adjusted for fixture location; comparison uses original trajectory, not candidate against itself.

The portable test passed5/5 in a small local validation directory with read-only dependency links. It verifies affected-only common pivot rotation, unchanged outside support across signed cycles, reversal/seeks, endpoint continuity, reset/dispose pose/attribute preservation. See portable-tests.tap. Frozen baseline remains unchanged.

## Isolated CI recipe (after existing restore-watch-candidate.py)

Place overlay folder at qa/detour-overlay (do NOT include validation/ or dereference its dependency symlinks).

```
python3 qa/detour-overlay/apply-overlay.py candidate
python3 qa/detour-overlay/apply-overlay.py candidate --apply
cd candidate
node tests/fork-contact-integration.test.mjs
node --test --test-concurrency=1 tests/*.test.mjs
node scripts/validate.mjs
```

Applier preflights all identities before writing, refuses repository/frozen targets and requires isolated target directory named candidate. Writes atomically, preserving underlying hardlinked source copies. It does not fetch, publish or update Git.

## Manifest/source identity impact

Update manifest identities for2 changed root scripts; add1 root helper. Unit fixture/test are not added to deployment manifest. Add helper BEFORE running tools/capture-provenance.mjs so it belongs to captured source identity (expected first-party count124→125). Regenerate quality-study/viewer-revision.json and .js, then update their manifest rows. Applier performs this sequence and writes detour-overlay-receipt.json. No hand-edited digest, disabled validation, model replacement or full release packing. An eventual release builder must use this newly validated manifest and produce its own new content/release ID; old shared asset owners stay unchanged.

## Actual browser gates

1. Initial ready with no source/load/console errors; saved-view revision and contactDetour metadata present, new source identity verified, cap still active after Reset.
2. Slow mechanism playback through the brief first drop, forward/reversed seek, pause/resume and cycle wrap. Confirm all fork components coherent and no visual jump. Numerical source correction is extremely small; do not promise visible improvement.
3. Winding in both directions, pulled time setting, reseat, interruptions; existing applyClockPose order also applies winding/setting/calendar. Verify source99/111–115 ownership is not overwritten unexpectedly.
4. Explode/reassemble (mechanics frozen while active), Reset, save/restore/resave and repeated calls. Verify no accumulating correction or stale provenance.
5. Current comparison/material/quality paths and error logs remain intact.

Finite contact evidence is135,980 phase/depth pair-sections for5 selected pairs, NOT full3D/all-tooth/fixed-neighbor/dynamics/manufacturing clearance. Browser validation remains pending. Do not mark the full moving-parts task complete from this overlay alone.

The existing UI scrub/frame cadence may not land inside the sub-microsecond detour support. Browser interaction checks validate coherent integration and surrounding behavior, not direct visual proof of that exact pose. Exact-pose evidence comes from the actual-mesh runtime test and finite numerical audit; do not invent a scene-seek API or force hidden controls to claim otherwise.
