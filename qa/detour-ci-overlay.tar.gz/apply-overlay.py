"""Read-only preflight by default. --apply targets an isolated restored CI candidate only."""
import argparse,hashlib,json,pathlib,os,subprocess
A=argparse.ArgumentParser();A.add_argument('target');A.add_argument('--apply',action='store_true');a=A.parse_args()
here=pathlib.Path(__file__).resolve().parent;root=pathlib.Path(a.target).resolve();spec=json.loads((here/'overlay-manifest.json').read_text())
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while b:=f.read(1024*1024):h.update(b)
 return h.hexdigest()
def safe(p):
 assert p.is_relative_to(root),p
 for q in [p,*p.parents]:
  if q==root:break
  assert not q.is_symlink(),f'No symlink writes: {q}'
def atomic(p,data):
 safe(p);p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_name(p.name+'.detour-tmp');assert not tmp.exists();tmp.write_bytes(data);os.replace(tmp,p)
for p,h in spec['baselineChecks'].items():assert sha(root/p)==h,f'Wrong baseline: {p}'
for x in spec['payload']:
 p=here/'files'/x['path'];assert sha(p)==x['sha256'] and p.stat().st_size==x['bytes'],x['path']
 dst=root/x['path']
 if x['beforeSha256'] is None:assert not dst.exists(),f'Expected absent: {dst}'
 else:assert sha(dst)==x['beforeSha256'],f'Wrong original: {dst}'
m=json.loads((root/'deployment-manifest.json').read_text());rows={x['path']:x for x in m['files']};assert len(rows)==len(m['files'])
for name in ['assembly-escapement.js','assembly-review.js','quality-study/viewer-revision.json','quality-study/viewer-revision.js']:
 assert rows[name]['sha256']==sha(root/name),f'Stale baseline manifest: {name}'
print('PASS: 8 baseline hashes, all payload hashes/absence conditions, and relevant manifest entries match frozen cap v2')
print('Impact: add1 deployed first-party helper; update2 viewer sources; regenerate2 viewer-revision files and their manifest rows. New unit test + original-path fixture remain QA-only.')
if not a.apply:raise SystemExit(0)
assert root.name=='candidate','--apply requires isolated restored directory named candidate'
assert not (root/'.git').exists(),'Never apply to repository checkout'
assert 'watch-cap-integration' not in str(root),'Never apply to frozen source'
safe(root/'tools/capture-provenance.mjs')
for x in spec['payload']:atomic(root/x['path'],(here/'files'/x['path']).read_bytes())
for x in spec['payload']:
 if x['path'].startswith('tests/'):continue
 rows[x['path']]={'path':x['path'],'sizeBytes':x['bytes'],'sha256':x['sha256']}
def manifest():
 m['files']=sorted(rows.values(),key=lambda x:x['path']);atomic(root/'deployment-manifest.json',(json.dumps(m,indent=2,ensure_ascii=False)+'\n').encode())
manifest() # New helper must be included BEFORE source identity generation.
for name in ['quality-study/viewer-revision.json','quality-study/viewer-revision.js']:
 atomic(root/name,(root/name).read_bytes()) # Break any pre-existing hardlink before generator writes.
subprocess.run(['node','tools/capture-provenance.mjs'],cwd=root,check=True)
for name in ['quality-study/viewer-revision.json','quality-study/viewer-revision.js']:
 rows[name]={'path':name,'sizeBytes':(root/name).stat().st_size,'sha256':sha(root/name)}
manifest()
receipt={'kind':'private-detour-overlay','sourceDigest':json.loads((root/'quality-study/viewer-revision.json').read_text())['digest'],'payload':spec['payload'],'deployedFiles':len(rows),'scope':spec['scope']}
atomic(root/'detour-overlay-receipt.json',(json.dumps(receipt,indent=2)+'\n').encode());print('Applied privately, source identities regenerated. Run actual mesh tests/full suite/browser before any release decision.')
