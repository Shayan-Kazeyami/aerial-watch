import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {register} from 'node:module';
import vm from 'node:vm';
import {createDeferredComparisonDetails} from '../assembly-comparison-loading.js';
import {createFormDetails} from '../assembly-form-details.js';
import {createFrontArchitecture} from '../assembly-front-architecture.js';
import {createResourceScope,createObjectTreeDisposer} from '../assembly-state.js';
register('../scripts/three-module-map.mjs',import.meta.url);
const {GLTFLoader}=await import('../vendor/loaders/GLTFLoader.js');
const runtime=await readFile(new URL('../assembly-review.js',import.meta.url),'utf8');
const sync=runtime.slice(runtime.indexOf('function syncFrontDetails()'),runtime.indexOf('let scale ='));
const install=runtime.slice(runtime.indexOf('async function loadFrontArchitecture()'),runtime.indexOf('function initializeBaseline('));
// Keep exact delivered arrays and node transforms, but omit unrelated baseline
// meshes from this focused fixture so low-memory runs need not decode a whole watch.
function compactBaseline(buffer){
 const jsonBytes=buffer.readUInt32LE(12),g=JSON.parse(buffer.toString('utf8',20,20+jsonBytes)),bin=buffer.subarray(28+jsonBytes);
 const nodes=g.nodes.filter(n=>n.extras?.assemblyId==='CASE'||[0,149,155].includes(n.extras?.sourceIndex));
 const accessors=[],bufferViews=[],meshes=[],chunks=[];let offset=0;
 const accessor=index=>{
  const a=g.accessors[index],v=g.bufferViews[a.bufferView],data=bin.subarray(v.byteOffset||0,(v.byteOffset||0)+v.byteLength);
  const padded=Buffer.alloc(Math.ceil(data.length/4)*4);data.copy(padded);chunks.push(padded);
  bufferViews.push({...v,buffer:0,byteOffset:offset});offset+=padded.length;
  accessors.push({...a,bufferView:bufferViews.length-1});return accessors.length-1;
 };
 for(const n of nodes){
  const m=g.meshes[n.mesh];meshes.push({...m,primitives:m.primitives.map(p=>({...p,attributes:Object.fromEntries(Object.entries(p.attributes).map(([k,v])=>[k,accessor(v)])),indices:accessor(p.indices)}))});n.mesh=meshes.length-1;
 }
 const compact={...g,nodes,meshes,accessors,bufferViews,buffers:[{byteLength:offset}],scenes:[{nodes:nodes.map((_,i)=>i)}],scene:0};
 const encoded=Buffer.from(JSON.stringify(compact)),json=Buffer.alloc(Math.ceil(encoded.length/4)*4,32);encoded.copy(json);
 const output=Buffer.alloc(28+json.length+offset);output.writeUInt32LE(0x46546c67,0);output.writeUInt32LE(2,4);output.writeUInt32LE(output.length,8);
 output.writeUInt32LE(json.length,12);output.writeUInt32LE(0x4e4f534a,16);json.copy(output,20);output.writeUInt32LE(offset,20+json.length);output.writeUInt32LE(0x004e4942,24+json.length);Buffer.concat(chunks).copy(output,28+json.length);return output;
}
const bytes=new Map();
for(const path of ['rebuild/assembly.glb','open-front/open-front-plates.glb','quality-study/form-legibility-r01.glb','quality-study/front-architecture-r07.glb']){
 const b=await readFile(new URL('../'+path,import.meta.url));bytes.set(path,path==='rebuild/assembly.glb'?compactBaseline(b):b);
}
const parse=async path=>{const b=bytes.get(path);return new GLTFLoader().parseAsync(b.buffer.slice(b.byteOffset,b.byteOffset+b.byteLength),'');};
const baseline=await parse('rebuild/assembly.glb'),supports=await parse('open-front/open-front-plates.glb');
const deferred=()=>{let resolve;const promise=new Promise(yes=>resolve=yes);return {promise,resolve};};
const tick=()=>new Promise(resolve=>setImmediate(resolve));

function fixture(){
 const root=baseline.scene.clone(true),plates=supports.scene.clone(true),source=[],exterior=[],openPlates=[];
 root.traverse(m=>{if(m.isMesh)(m.userData.sourceIndex===undefined?exterior:source).push(m);});plates.traverse(m=>{if(m.isMesh)openPlates.push(m);});
 const calendar=source.find(m=>m.userData.sourceIndex===149),caseMesh=exterior.find(m=>m.userData.assemblyId==='CASE');
 const sourceRestMatrices=new Map(source.map(m=>{m.updateMatrix();return [m.userData.sourceIndex,m.matrix.clone()];}));
 const originals=new Map([calendar,caseMesh,...openPlates].map(m=>[m,m.geometry])),resources=createResourceScope(),controller=new AbortController(),lifecycle={disposed:false};
 const calls=[],errors=[],released=[],waits=new Map(),entered=new Map();const state={comparison:false};
 const disposal=new WeakMap();const disposeObjectTree=root=>{if(!disposal.has(root))disposal.set(root,createObjectTreeDisposer(root));disposal.get(root)();};
 const context={source,exterior,openPlates,sourceRestMatrices,resources,lifecycle,parametricCase:null,capRefinement:null,formDetails:null,frontArchitecture:null,createFormDetails,createFrontArchitecture,disposeObjectTree,
  assetOptions:()=>({signal:controller.signal}),performanceMonitor:{load(){}},
  loadGLTFAsset:async(path,options)=>{
   assert.equal(options.signal,controller.signal);calls.push(path);const gltf=await parse(path);let count=0;
   gltf.scene.traverse(m=>{if(m.isMesh)m.geometry.addEventListener('dispose',()=>count++);});
   const meshes=[];gltf.scene.traverse(m=>{if(m.isMesh)meshes.push(m);});released.push(()=>({disposed:count,meshes:meshes.length}));
   entered.get(path)?.resolve();if(waits.has(path))await waits.get(path).promise;return {gltf,metrics:{url:path}};
  },
  inspectionMaterials:{restore(){}},premiumActive:()=>!state.comparison,openFrontActive:()=>true,$:()=>({checked:true}),
  presentationGate:{snapshot:()=>({enabled:true,interactive:true})},handClearance:null,crownVisual:null,
  premiumFace:{root:{visible:true}},dialFace:null,dialDetails:null,openDialDetails:null,dialDetailLazy:null,openDialDetailLazy:null,openFrontFrame:null,qualityDesign:null,
  PREMIUM_HIDDEN_SOURCES:[0,149,155],structuralSupportVisible:()=>true,URLSearchParams,location:{search:''},craftParts:[],interiorView:false,backplate:null,
  applyStrapInspectionVisibility(){},model:null,inspectionDisplay:{},
 };
 context.updateMaterials=()=>{context.syncFrontDetails();if(state.failAfterInstall==='form'&&context.formDetails||state.failAfterInstall==='architecture'&&context.frontArchitecture){state.failAfterInstall=null;throw Error('post-install refresh failed');}};context.visibility=()=>context.syncFrontDetails();
 vm.createContext(context);vm.runInContext(sync+'\n'+install,context);
 const loader=createDeferredComparisonDetails({loadForm:()=>context.loadFormDetails(),loadArchitecture:()=>context.loadFrontArchitecture(),onError:(error,stage)=>errors.push({stage,error})});context.comparisonDetails=loader;
 resources.own('deferred comparison loader',()=>loader.dispose());
 const show=value=>{state.comparison=value;context.syncFrontDetails();return loader.update(value);};
 const wait=path=>{waits.set(path,deferred());entered.set(path,deferred());return {started:entered.get(path).promise,finish:()=>waits.get(path).resolve()};};
 const dispose=()=>{lifecycle.disposed=true;controller.abort();resources.dispose();};
 const assertOriginal=()=>{for(const [mesh,geometry] of originals)assert.equal(mesh.geometry,geometry);};
 return {context,state,calls,errors,show,wait,dispose,assertOriginal,released,loader,originals,resources,calendar,sourceRestMatrices};
}

test('real assets and actual runtime callbacks never re-show late hidden comparison geometry',async()=>{
 const h=fixture(),form=h.wait('quality-study/form-legibility-r01.glb'),architecture=h.wait('quality-study/front-architecture-r07.glb');
 h.show(false);await tick();assert.deepEqual(h.calls,[]);
 const pendingForm=h.show(true);await form.started;h.show(false);form.finish();await pendingForm;
 assert.equal(h.calls.length,1);h.assertOriginal();assert.equal(h.context.formDetails.enabled,false);
 const pendingArchitecture=h.show(true);await architecture.started;
 for(let i=0;i<4;i++){h.show(false);h.show(true);}h.show(false);architecture.finish();await pendingArchitecture;
 h.assertOriginal();assert.equal(h.context.frontArchitecture.enabled,false);assert.equal(h.context.formDetails.enabled,false);
 for(let i=0;i<3;i++){await h.show(true);assert.equal(h.context.frontArchitecture.enabled,true);h.show(false);h.assertOriginal();}
 assert.equal(h.calls.length,2);assert.deepEqual(h.errors,[]);assert.ok(h.released.every(read=>read().disposed===read().meshes));
 h.dispose();h.dispose();h.assertOriginal();
});

for(const stage of ['form-legibility-r01','front-architecture-r07'])test(`actual pending ${stage} callback releases late parsed GLTF after disposal`,async()=>{
 const h=fixture(),wait=h.wait(`quality-study/${stage}.glb`),pending=h.show(true);await wait.started;h.dispose();wait.finish();await pending;
 h.assertOriginal();assert.deepEqual(h.errors,[]);assert.equal(h.loader.snapshot().disposed,true);
 assert.ok(h.released.every(read=>read().disposed===read().meshes));
 assert.equal(h.context.frontArchitecture,null);if(stage==='form-legibility-r01')assert.equal(h.context.formDetails,null);
});

test('baseline setup contains no eager comparison transfer or architecture install request',()=>{
 const setup=runtime.slice(runtime.indexOf('function initializeBaseline('),runtime.indexOf('const parametricCaseMode='));
 assert.doesNotMatch(setup,/form-legibility-r01|front-architecture-r07|loadFrontArchitecture\(/);
 assert.match(runtime,/resources\.own\('deferred historical comparison loading',\(\)=>comparisonDetails\.dispose\(\)\)/);
 assert.equal((runtime.match(/loadGLTFAsset\('quality-study\/form-legibility-r01\.glb'/g)||[]).length,1);
 assert.equal((runtime.match(/loadGLTFAsset\('quality-study\/front-architecture-r07\.glb'/g)||[]).length,1);
});

for(const stage of ['form','architecture'])test(`post-install ${stage} refresh failure rolls back ownership and retries without duplicate layers`,async()=>{
 const h=fixture();h.state.failAfterInstall=stage;await h.show(true);
 assert.equal(h.errors.length,1);assert.equal(h.errors[0].stage,stage);assert.equal(h.context.frontArchitecture,null);
 if(stage==='form'){assert.equal(h.context.formDetails,null);h.assertOriginal();}
 else assert.equal(h.context.formDetails.enabled,true);
 assert.equal(h.resources.snapshot().active.length,stage==='form'?1:2);
 h.show(false);await h.show(true);assert.equal(h.context.frontArchitecture.enabled,true);
 assert.equal(h.calls.length,3);assert.equal(h.resources.snapshot().active.length,3);
 h.dispose();h.assertOriginal();
});

test('late architecture preserves animated calendar pose and uses original rest matrices for geometry',async()=>{
 const h=fixture(),wait=h.wait('quality-study/front-architecture-r07.glb'),pending=h.show(true);await wait.started;
 h.calendar.rotateZ(.73);h.calendar.updateMatrix();const pose=h.calendar.matrix.toArray();
 wait.finish();await pending;assert.equal(h.context.frontArchitecture.enabled,true);assert.deepEqual(h.calendar.matrix.toArray(),pose);
 const candidate=await parse('quality-study/front-architecture-r07.glb');
 const targets=new Map(h.context.openPlates.map(m=>[m.userData.replacementForSourceIndex,m.clone()]));targets.set(149,h.calendar.clone());
 const expected=createFrontArchitecture({targets,candidateScene:candidate.scene,revision:'r07',restMatrices:h.sourceRestMatrices});expected.setEnabled(true);
 assert.deepEqual(h.calendar.geometry.attributes.position.array,targets.get(149).geometry.attributes.position.array);
 expected.dispose();createObjectTreeDisposer(candidate.scene)();h.show(false);h.assertOriginal();assert.deepEqual(h.calendar.matrix.toArray(),pose);h.dispose();
});
