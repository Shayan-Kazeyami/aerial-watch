import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';
const runtime=readFileSync(new URL('../assembly-review.js',import.meta.url),'utf8');
test('GPU timing is opt-in, disposed, exported and reset with diagnostics',()=>{
 assert.match(runtime,/createGPUTiming\(renderer.getContext\?\.\(\),\{enabled:!passProfiling&&new URLSearchParams\(location.search\).get\('profile'\)==='1'\}\)/);
 assert.match(runtime,/resources.own\('optional local GPU timing',\(\)=>gpuTiming.dispose\(\)\)/);
 assert.match(runtime,/gpuTiming:gpuTiming.snapshot\(\)/);
 assert.match(runtime,/performanceMonitor.reset\(\);gpuTiming.reset\(\)/);
 const frame=runtime.slice(runtime.indexOf('function frame(time)'));
 assert(frame.indexOf('gpuTiming.poll()')<frame.indexOf('if (skipViewerFrame'));
 assert(frame.indexOf('gpuTiming.poll()')<frame.indexOf('if(time-last<15)'));
});
test('both capture and live render close owned GPU samples even when rendering throws',()=>{
 // Extract the two exact owned timing regions by their unique begin/finally
 // anchors. The render body can legitimately contain nested object/if braces.
 const beginMarker='const gpuSample=gpuTiming.begin();',endMarker='}finally{if(gpuSample)gpuTiming.end();}';
 const blocks=[];let cursor=0;
 while((cursor=runtime.indexOf(beginMarker,cursor))!==-1){const end=runtime.indexOf(endMarker,cursor);assert.notEqual(end,-1,'owned GPU sample must have its finally closure');const next=runtime.indexOf(beginMarker,cursor+beginMarker.length);assert.ok(next===-1||end<next,'each begin must close before another timing region');blocks.push(runtime.slice(cursor,end+endMarker.length));cursor=end+endMarker.length;}
 assert.equal(blocks.length,2);
 for(const block of blocks)for(const begin of [true,false])for(const throws of [true,false])for(const acknowledgementThrows of [true,false]){
  let ends=0,renderCalls=0,acknowledgements=0;
  const hasAcknowledgement=block.includes('pendingCaptureFrame');
  const context={applySurfaceSolo(){},gpuTiming:{begin:()=>begin,end:()=>ends++},composer:{render(){renderCalls++;if(throws)throw Error('render failure');}},renderedFrames:0,dirty:true,premiumRequested:true,premiumActive:()=>true,presentationGate:{rendered(){}},pendingCaptureFrame:7,
   $:()=>({getBoundingClientRect:()=>({width:400,height:380})}),renderer:{domElement:{width:800,height:760}},CustomEvent:class{constructor(type,options){this.type=type;this.detail=options.detail;}},document:{dispatchEvent(event){acknowledgements++;assert.equal(event.type,'atelier:capture-frame-rendered');assert.equal(event.detail.requestId,7);if(acknowledgementThrows)throw Error('acknowledgement failure');}}};
  if(throws)assert.throws(()=>vm.runInNewContext(block,context),/render failure/);
  else if(hasAcknowledgement&&acknowledgementThrows)assert.throws(()=>vm.runInNewContext(block,context),/acknowledgement failure/);
  else vm.runInNewContext(block,context);
  assert.equal(renderCalls,1);assert.equal(ends,Number(begin));assert.equal(acknowledgements,Number(hasAcknowledgement&&!throws));
 }

});

test('pass profiling is opt-in, mutually exclusive with frame timing and exported',()=>{assert.match(runtime,/profilePass/);assert.match(runtime,/!passProfiling&&new URLSearchParams/);assert.match(runtime,/gpuPassTiming:passTiming\?\.snapshot\(\)\?\?null/);assert.match(runtime,/passTiming\?\.poll\(\)/);assert.match(runtime,/passTiming\?\.reset\(\)/);assert.match(runtime,/optional GPU pass timing/);});
