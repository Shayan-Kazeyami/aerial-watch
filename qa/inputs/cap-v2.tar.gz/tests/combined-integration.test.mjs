import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {loadProgressiveAssembly} from '../assembly-loading.js';
import {createResourceScope,createObjectTreeDisposer,disposeObjectTree} from '../assembly-state.js';
import {Group,Mesh,BufferGeometry,MeshBasicMaterial} from '../vendor/three.module.js';
const code=(await readFile(new URL('../assembly-review.js',import.meta.url),'utf8')).replaceAll('\r\n','\n');
const block=code.slice(code.indexOf('loadProgressiveAssembly({',code.indexOf('const parametricCaseMode=')));
const start=block.indexOf('loadBaseline:')+'loadBaseline:'.length,end=block.indexOf(',\n  loadMetadata:',start);
const wrapper=block.slice(start,end).replace("await import('./assembly-case-combined.js')",'await importReplacement()');
const disposer=block.match(/disposeUnused:(.*),\n  loadBaseline:/)[1];
const tick=()=>new Promise(resolve=>setImmediate(resolve));
function harness({defer=false,mode='fine-combined',prepareError=null,enableError=null,importError=null}={}){
 const counts={original:0,derived:0,originalMaterial:0,derivedMaterial:0,imports:0},original=new BufferGeometry(),derived=new BufferGeometry(),originalMaterial=new MeshBasicMaterial(),derivedMaterial=new MeshBasicMaterial();
 original.addEventListener('dispose',()=>counts.original++);derived.addEventListener('dispose',()=>counts.derived++);originalMaterial.addEventListener('dispose',()=>counts.originalMaterial++);derivedMaterial.addEventListener('dispose',()=>counts.derivedMaterial++);
 const mesh=new Mesh(original,originalMaterial);mesh.userData.assemblyId='CASE';const root=new Group();root.add(mesh);const baseline={gltf:{scene:root}},objectDisposers=new WeakMap(),controller=new AbortController(),lifecycle={disposed:false,signal:controller.signal},resources=createResourceScope(),loadWarnings=[];let release,entered;
 const gate=defer?new Promise(resolve=>release=resolve):Promise.resolve(),started=new Promise(resolve=>entered=resolve);
 const ownedObjectTreeDisposer=root=>{if(!objectDisposers.has(root))objectDisposers.set(root,createObjectTreeDisposer(root));return objectDisposers.get(root);};
 let factoryChosen=null;
 const prepare=async(kind)=>{factoryChosen=kind;entered();await gate;if(prepareError)throw prepareError;let enabled=false,disposed=false;return {setTextureQuality(){},mesh,audit:{revision:'test'},get enabled(){return enabled;},setEnabled(v){if(enableError)throw enableError;enabled=v;mesh.geometry=v?derived:original;mesh.material=v?derivedMaterial:originalMaterial;},dispose(){if(disposed)return;disposed=true;if(mesh.geometry===derived){mesh.geometry=original;mesh.material=originalMaterial;}enabled=false;derived.dispose();derivedMaterial.dispose();}};};
 const importReplacement=async()=>{counts.imports++;if(importError)throw importError;return {createCombinedCaseReplacement:()=>prepare('combined'),loadCombinedCaseAsset:async()=>({scene:true})};};
 const make=Function('loadGLTFAsset','parametricCaseMode','ownedObjectTreeDisposer','lifecycle','objectDisposers','loadWarnings','importReplacement','assetOptions','loadJSONAsset','location','quality','renderer','installCapRefinement',`let parametricCase=null,capRefinement=null;return ${wrapper};`);
 const loadBaseline=make(async()=>baseline,mode,ownedObjectTreeDisposer,lifecycle,objectDisposers,loadWarnings,importReplacement,()=>({}),async()=>({}),{search:''},'studio',{capabilities:{getMaxAnisotropy:()=>16}},async()=>{const cap=await prepare('cap');cap.setEnabled(true);return cap;});
 const disposeUnused=Function('ownedObjectTreeDisposer',`${code.match(/function disposeObjectTree\(root\)\{[^\n]+/)[0]} return ${disposer};`)(ownedObjectTreeDisposer);
 const run=extra=>loadProgressiveAssembly({loadBaseline,loadMetadata:async()=>({}),loadProposal:async()=>{throw Error('optional proposal');},onBaseline(){resources.own('baseline',ownedObjectTreeDisposer(root));},onProposal(){},disposeUnused,signal:lifecycle.signal,...extra});
 return {counts,mesh,root,baseline,original,derived,originalMaterial,resources,controller,lifecycle,release,started,run,disposeUnused,loadWarnings,get factoryChosen(){return factoryChosen;}};
}
const disposedCounts={original:1,derived:1,originalMaterial:1,derivedMaterial:1,imports:1};
test('exact runtime wrapper restores and disposes both source and replacement after initialization failure',async()=>{
 const h=harness();await assert.rejects(h.run({onBaseline(){throw Error('initialization failure');}}),/initialization failure/);h.disposeUnused(h.baseline);assert.deepEqual(h.counts,disposedCounts);assert.equal(h.mesh.geometry,h.original);
});
test('metadata failure while replacement preparation is pending cleans late baseline through combined boundary',async()=>{
 const h=harness({defer:true});await assert.rejects(h.run({loadMetadata:async()=>{await h.started;throw Error('metadata failure');}}),/metadata failure/);h.release();await tick();h.disposeUnused(h.baseline);assert.deepEqual(h.counts,disposedCounts);assert.equal(h.mesh.geometry,h.original);
});
test('cancellation before replacement completion restores source and disposes each resource once',async()=>{
 const h=harness({defer:true});const running=h.run();await h.started;h.lifecycle.disposed=true;h.controller.abort();h.release();await assert.rejects(running,{name:'AbortError'});h.disposeUnused(h.baseline);assert.deepEqual(h.counts,disposedCounts);assert.equal(h.mesh.geometry,h.original);
});
test('successful initialization and repeated unmount disposal share combined ownership',async()=>{
 const h=harness();await h.run();assert.equal(h.mesh.geometry,h.derived);h.resources.dispose();h.resources.dispose();h.disposeUnused(h.baseline);assert.deepEqual(h.counts,disposedCounts);assert.equal(h.mesh.geometry,h.original);
});
test('default source mode installs fixed cap without importing combined replacement',async()=>{
 const h=harness({mode:'source'});await h.run();assert.equal(h.mesh.geometry,h.derived);assert.equal(h.factoryChosen,'cap');assert.equal(h.counts.imports,0);h.resources.dispose();assert.deepEqual(h.counts,{original:1,derived:1,originalMaterial:1,derivedMaterial:1,imports:0});
});
test('runtime maps CASE material arrays explicitly and prevents older form geometry from overwriting it',()=>{
 assert.match(code,/baseMaterials\.set\(mesh,parametricCase\?\.enabled&&mesh===parametricCase\.mesh\?parametricCase\.plainMaterials/);
 assert.match(code,/finishMaterials\.set\(mesh,parametricCase\?\.enabled&&mesh===parametricCase\.mesh\?parametricCase\.materials/);
 assert.match(code,/preserveCaseGeometry:!!parametricCase\?\.enabled/);
 assert.doesNotMatch(code,/createCaseCapRefinement|caseCapRefinement/);
 assert.match(code,/parametricCase:parametricCaseSnapshot\(\)/);
});


test('selected combined CASE holds baseline initialization until verified replacement is installed',async()=>{
 const h=harness({defer:true});let initialized=0;const running=h.run({onBaseline(){initialized++;assert.equal(h.mesh.geometry,h.derived);}});await h.started;await tick();assert.equal(initialized,0);assert.equal(h.mesh.geometry,h.original);h.release();await running;assert.equal(initialized,1);h.disposeUnused(h.baseline);assert.deepEqual(h.counts,disposedCounts);
});
test('selected replacement preparation failure is fatal, never initializes old-case fallback, and disposes raw baseline',async()=>{
 const h=harness({prepareError:Error('selected CASE hash failure')});let initialized=0;await assert.rejects(h.run({onBaseline(){initialized++;}}),/selected CASE hash failure/);assert.equal(initialized,0);assert.equal(h.loadWarnings.length,0);assert.equal(h.counts.original,1);assert.equal(h.counts.originalMaterial,1);assert.equal(h.counts.derived,0);h.disposeUnused(h.baseline);assert.equal(h.counts.original,1);
});
test('selected replacement module failure is fatal and disposes baseline before it can be presented',async()=>{
 const h=harness({importError:Error('module failed')});let initialized=0;await assert.rejects(h.run({onBaseline(){initialized++;}}),/module failed/);assert.equal(initialized,0);assert.equal(h.counts.original,1);assert.equal(h.counts.originalMaterial,1);
});
test('replacement activation failure cleans both ownership layers without presentation',async()=>{
 const h=harness({enableError:Error('activation failed')});let initialized=0;await assert.rejects(h.run({onBaseline(){initialized++;}}),/activation failed/);assert.equal(initialized,0);h.disposeUnused(h.baseline);assert.deepEqual(h.counts,disposedCounts);
});
test('baseline replacement failure reaches fatal loading handler, not optional proposal warning',()=>{
 assert.match(code,/catch\(error\)\{try\{replacement\?\.dispose\(\);\}finally\{disposeOriginal\(\);\}throw error;\}/);
 assert.match(block,/\}\)\.catch\(error=>\{if\(!lifecycle.disposed\)fail\(/);
});


test('combined CASE is a distinct mandatory factory and keeps baseline hidden until completion',async()=>{const h=harness({mode:'fine-combined',defer:true});let initialized=0;const run=h.run({onBaseline(){initialized++;assert.equal(h.mesh.geometry,h.derived);}});await h.started;assert.equal(h.factoryChosen,'combined');assert.equal(initialized,0);h.release();await run;assert.equal(initialized,1);h.disposeUnused(h.baseline);assert.deepEqual(h.counts,disposedCounts);});
test('combined CASE selected load failure never falls back to proxy or source',async()=>{const h=harness({mode:'fine-combined',prepareError:Error('strict fine decoding failed')});let initialized=0;await assert.rejects(h.run({onBaseline(){initialized++;}}),/strict fine decoding failed/);assert.equal(h.factoryChosen,'combined');assert.equal(initialized,0);assert.equal(h.counts.imports,1);assert.equal(h.counts.original,1);});
test('combined CASE cancellation disposes late prepared geometry and never initializes baseline',async()=>{const h=harness({mode:'fine-combined',defer:true});let initialized=0;const running=h.run({onBaseline(){initialized++;}});await h.started;h.controller.abort();h.release();await assert.rejects(running,{name:'AbortError'});assert.equal(initialized,0);h.disposeUnused(h.baseline);assert.deepEqual(h.counts,disposedCounts);});

test('default and unknown modes never import or fetch selected fine geometry',async()=>{for(const mode of ['source','parametric','','unknown']){const h=harness({mode});await h.run();assert.equal(h.counts.imports,0);assert.equal(h.factoryChosen,'cap');assert.equal(h.mesh.geometry,h.derived);h.resources.dispose();}});

test('fixed cap prevents later form detail geometry from overwriting it',()=>{assert.match(code,/preserveCaseGeometry:!!parametricCase\?\.enabled\|\|!!capRefinement\?\.active/);});
