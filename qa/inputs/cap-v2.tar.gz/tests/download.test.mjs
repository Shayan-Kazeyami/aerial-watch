import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createDownloadManager} from '../assembly-download.js';
test('download URL survives activation then releases on timeout or teardown',()=>{
 const events=[],timers=[];let sequence=0;
 const link={click(){events.push('click')},remove(){events.push('remove')}};
 const m=createDownloadManager({document:{createElement:()=>link,body:{append:()=>events.push('append')}},urlAPI:{createObjectURL:()=>`blob:${++sequence}`,revokeObjectURL:u=>events.push(u)},setTimer:(fn,ms)=>{timers.push({fn,ms});return timers.length;},clearTimer:id=>events.push(`clear:${id}`)});
 assert(m.save(new Blob(),'test.png').requested);assert.deepEqual(events,['append','click','remove']);assert.equal(timers[0].ms,60000);assert.equal(m.pendingCount,1);
 timers[0].fn();assert.equal(m.pendingCount,0);assert(events.includes('blob:1'));
 m.save(new Blob(),'two.png');m.dispose();m.dispose();assert.equal(m.pendingCount,0);assert.throws(()=>m.save(new Blob(),'three.png'),/closed/);
});

test('failed DOM preparation, activation and timer scheduling cannot leak a URL',()=>{
 for(const stage of ['create','append','timer','click']){
  let created=0,revoked=0,cleared=0,removed=0;
  const fail=where=>{if(stage===where)throw Error(where);};
  const manager=createDownloadManager({document:{createElement(){fail('create');return {click(){fail('click');},remove(){removed++;}};},body:{append(){fail('append');}}},urlAPI:{createObjectURL(){created++;return 'blob:test';},revokeObjectURL(){revoked++;}},setTimer(){fail('timer');return 1;},clearTimer(){cleared++;}});
  assert.throws(()=>manager.save(new Blob(),'test.png'),new RegExp(stage));
  assert.equal(manager.pendingCount,0);assert.equal(revoked,created);assert.equal(removed,stage==='create'?0:1);assert.equal(cleared,stage==='click'?1:0);
  manager.dispose();assert.equal(revoked,created);
 }
});
test('navigation triggered by activation disposes its already-owned download URL',()=>{
 let revoked=0,manager;
 manager=createDownloadManager({document:{createElement:()=>({click:()=>manager.dispose(),remove(){}}),body:{append(){}}},urlAPI:{createObjectURL:()=> 'blob:test',revokeObjectURL:()=>revoked++},setTimer:()=>1,clearTimer(){}});
 assert.equal(manager.save(new Blob(),'test.png').requested,true);assert.equal(manager.pendingCount,0);assert.equal(revoked,1);manager.dispose();assert.equal(revoked,1);
});
