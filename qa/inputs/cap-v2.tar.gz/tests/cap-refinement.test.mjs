import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {BufferGeometry,Float32BufferAttribute,Mesh,Group} from '../vendor/three.module.js';
import {installCapRefinement} from '../assembly-cap-refinement.js';
const data=await readFile(new URL('./fixtures/cap-source-position.bin',import.meta.url));
const floats=new Float32Array(data.buffer.slice(data.byteOffset,data.byteOffset+data.byteLength));
function fixture(){const root=new Group(),g=new BufferGeometry();g.setAttribute('position',new Float32BufferAttribute(floats,3));g.setAttribute('normal',new Float32BufferAttribute(new Float32Array(floats.length).fill(.25),3));g.setIndex([0,1,2]);g.addGroup(0,3,0);const mesh=new Mesh(g);mesh.userData.assemblyId='CASE';root.add(mesh);return {root,g,mesh};}
test('fixed cap installs once, preserves source and unchanged attributes, and cleans exactly once',async()=>{
 const {root,g,mesh}=fixture(),before=g.attributes.position.array.slice();let sourceDisposals=0;g.addEventListener('dispose',()=>sourceDisposals++);
 const cap=await installCapRefinement(root),candidate=mesh.geometry;let n=0;candidate.addEventListener('dispose',()=>n++);
 assert.equal(cap.active,true);assert.equal(cap.audit.fixedGeometry,true);assert.notEqual(candidate,g);assert.deepEqual(g.attributes.position.array,before);
 assert.deepEqual(candidate.attributes.normal.array,g.attributes.normal.array);assert.deepEqual(candidate.index.array,g.index.array);assert.deepEqual(candidate.groups,g.groups);
 assert.equal(cap.setEnabled,undefined);assert.equal(cap.reset,undefined);
 await assert.rejects(installCapRefinement(root),/position hash/);assert.equal(mesh.geometry,candidate);
 cap.dispose();cap.dispose();assert.equal(n,1);assert.equal(sourceDisposals,0);assert.equal(mesh.geometry,g);assert.equal(cap.active,false);g.dispose();
});
test('repeat complete load/dispose cycles do not retain old geometry',async()=>{for(let i=0;i<3;i++){const {root,g,mesh}=fixture();const cap=await installCapRefinement(root);assert.equal(cap.active,true);cap.dispose();assert.equal(mesh.geometry,g);g.dispose();}});
test('already aborted and abort during digest never swap geometry',async()=>{for(const early of [true,false]){const {root,g,mesh}=fixture(),controller=new AbortController();if(early)controller.abort();const pending=installCapRefinement(root,{signal:controller.signal});if(!early)controller.abort();await assert.rejects(pending,{name:'AbortError'});assert.equal(mesh.geometry,g);g.dispose();}});
test('changed source and replaced geometry fail closed',async()=>{
 for(const mode of ['before','during','replace']){const {root,g,mesh}=fixture();if(mode==='before')g.attributes.position.array[0]+=.1;
 const pending=installCapRefinement(root);if(mode==='during')g.attributes.position.array[0]+=.1;if(mode==='replace')mesh.geometry=new BufferGeometry();
 await assert.rejects(pending,/hash|changed during/);if(mode!=='replace')assert.equal(mesh.geometry,g);else mesh.geometry.dispose();g.dispose();}
});
test('disposal never clobbers a later geometry owner',async()=>{const {root,g,mesh}=fixture(),cap=await installCapRefinement(root),later=new BufferGeometry();mesh.geometry=later;cap.dispose();assert.equal(mesh.geometry,later);later.dispose();g.dispose();});
test('CASE selection fails closed on missing or duplicate meshes',async()=>{const {root,g,mesh}=fixture();root.remove(mesh);await assert.rejects(installCapRefinement(root),/exactly one/);root.add(mesh);const duplicate=new Mesh(g);duplicate.userData.assemblyId='CASE';root.add(duplicate);await assert.rejects(installCapRefinement(root),/exactly one/);g.dispose();});
test('viewer installs before baseline return and Reset cannot turn off fixed cap',async()=>{
 const source=await readFile(new URL('../assembly-review.js',import.meta.url),'utf8');
 const load=source.slice(source.indexOf('loadBaseline:async()=>'),source.indexOf('loadMetadata:()=>'));
 assert.ok(load.indexOf('await installCapRefinement')<load.indexOf('return baseline;'));
 assert.match(load,/refinement\.dispose\(\);\}finally\{disposeOriginal\(\);/);
 const reset=source.slice(source.indexOf("$('reset').onclick"),source.indexOf("document.addEventListener('keydown'"));assert.doesNotMatch(reset,/capRefinement|installCap|geometry\s*=/);
});
test('concurrent installs allow one owner and dispose rejected candidate without changing winner',async()=>{
 const {root,g,mesh}=fixture();const results=await Promise.allSettled([installCapRefinement(root),installCapRefinement(root)]);
 assert.equal(results.filter(r=>r.status==='fulfilled').length,1);assert.equal(results.filter(r=>r.status==='rejected').length,1);
 const owner=results.find(r=>r.status==='fulfilled').value;assert.equal(owner.active,true);assert.notEqual(mesh.geometry,g);owner.dispose();assert.equal(mesh.geometry,g);g.dispose();
});
