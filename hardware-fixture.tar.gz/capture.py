import asyncio,json,pathlib,base64
from playwright.async_api import async_playwright
R=pathlib.Path('hardware-retopo-qa');O=R/'evidence';O.mkdir(exist_ok=True)
async def main():
 rows=[]
 async with async_playwright() as p:
  b=await p.chromium.launch(headless=True,args=['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader']);page=await b.new_page(viewport={'width':1000,'height':1000});await page.goto('http://127.0.0.1:8876/fixture/');await page.wait_for_function('window.ready===true')
  for sid in [39,80,54,74,76]:
   for view in ['whole','macro','nearest']:
    for wire in [False,True]:
     for mode in ['before','after']:
      d=await page.evaluate('(p)=>show(...p)',[sid,mode,view,wire]);im=d.pop('image');(O/f'{sid}-{view}-{"wire"if wire else"shade"}-{mode}.png').write_bytes(base64.b64decode(im.split(',')[1]));rows.append(d)
  await b.close()
 (O/'capture-state.json').write_text(json.dumps(rows,indent=2))
asyncio.run(main())
