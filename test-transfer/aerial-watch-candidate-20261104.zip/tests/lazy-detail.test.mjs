import test from 'node:test';
import assert from 'node:assert/strict';
import {createLazyDetail} from '../assembly-lazy-detail.js';

test('creates on demand, attaches once, reuses, and disposes once',()=>{
 let created=0,attached=0,disposed=0;
 const lazy=createLazyDetail({create:()=>{created++;return {dispose(){disposed++;}}},attach:()=>attached++});
 assert.equal(lazy.value,null);assert.equal(created,0);
 assert.equal(lazy.ensure(),lazy.ensure());assert.deepEqual([created,attached],[1,1]);
 lazy.dispose();lazy.dispose();assert.equal(disposed,1);assert.throws(()=>lazy.ensure(),/disposed/);
});
test('failed attachment releases the created resource and may be retried',()=>{
 let disposed=0,attempts=0;
 const lazy=createLazyDetail({create:()=>({dispose(){disposed++;}}),attach:()=>{if(++attempts===1)throw Error('attach failed');}});
 assert.throws(()=>lazy.ensure(),/attach failed/);assert.equal(disposed,1);assert.equal(lazy.value,null);
 lazy.ensure();lazy.dispose();assert.equal(disposed,2);
});
