import {test} from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {createInspectionMaterials,applyStrapInspectionVisibility} from '../assembly-inspection.js';
import {readFileSync} from 'node:fs';
const runtime=readFileSync(new URL('../assembly-review.js',import.meta.url),'utf8');
const fn=runtime.slice(runtime.indexOf('function syncFrontDetails()'),runtime.indexOf('let scale ='));
function harness(){
 const dial={visible:true,userData:{assemblyId:'DIAL'}},state={premium:true,open:true,finished:true};
 const crown=[];const context={applyStrapInspectionVisibility,model:null,inspectionDisplay:{hideStrap:false},inspectionMaterials:createInspectionMaterials({cloneMaterial:m=>m.clone()}),premiumActive:()=>state.premium,openFrontActive:()=>state.open,$:()=>({checked:state.finished}),presentationGate:{snapshot:()=>({enabled:true,interactive:state.interactive!==false})},handClearance:null,frontArchitecture:null,formDetails:null,crownVisual:{setEnabled:v=>crown.push(v)},premiumFace:{root:{visible:false}},dialFace:dial,dialDetails:{group:{visible:true}},openDialDetails:{group:{visible:true}},openFrontFrame:null,qualityDesign:null,source:[],exterior:[dial],PREMIUM_HIDDEN_SOURCES:[],openPlates:[],craftParts:[],interiorView:false,backplate:null};vm.createContext(context);vm.runInContext(fn,context);return {context,state,dial,crown};
}
test('actual runtime visibility helper suppresses the entire old dial atomically on the first call, without a repair pass',()=>{
 const h=harness();h.context.syncFrontDetails();assert.equal(h.context.premiumFace.root.visible,true);assert.equal(h.dial.visible,false);assert.equal(h.context.dialDetails.group.visible,false);assert.equal(h.context.openDialDetails.group.visible,false);assert.deepEqual(h.crown,[true]);
 // Late optional assets and option changes may restore base visibility before
 // invoking the helper. The first pass must still be renderable, every time.
 for(const finished of [false,true,true,false,true]){h.state.finished=finished;h.dial.visible=true;h.context.syncFrontDetails();assert.equal(h.context.dialDetails.group.visible,false);assert.equal(h.dial.visible,false);}
});
test('legacy print is deferred until comparison is requested after selected presentation',()=>{
 const h=harness();let made=0;h.context.dialDetails=null;h.context.openDialDetails=null;h.context.dialDetailLazy={ensure(){made++;return {group:{visible:false}}}};h.context.openDialDetailLazy={ensure(){made++;return {group:{visible:false}}}};
 h.state.interactive=false;h.state.premium=false;h.state.open=false;h.context.syncFrontDetails();assert.equal(made,0);
 h.state.interactive=true;h.state.premium=true;h.state.open=true;h.context.syncFrontDetails();assert.equal(made,0);
 h.state.premium=false;h.state.open=false;h.dial.visible=true;h.context.syncFrontDetails();assert.equal(made,1);assert.equal(h.context.dialDetails.group.visible,true);
 h.context.syncFrontDetails();assert.equal(made,1);
});
test('original comparison retains its dial and raw crown; returning to selected premium is atomic',()=>{
 const h=harness();h.context.syncFrontDetails();h.state.premium=false;h.state.open=false;h.dial.visible=true;h.context.syncFrontDetails();assert.equal(h.context.premiumFace.root.visible,false);assert.equal(h.context.dialDetails.group.visible,true);assert.equal(h.crown.at(-1),false);
 h.state.premium=h.state.open=true;h.context.syncFrontDetails();assert.equal(h.context.dialDetails.group.visible,false);assert.equal(h.context.premiumFace.root.visible,true);assert.equal(h.crown.at(-1),true);
});
