import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';
const runtime=readFileSync(new URL('../assembly-review.js',import.meta.url),'utf8');
test('GPU timing is opt-in, disposed, exported and reset with diagnostics',()=>{
 assert.match(runtime,/createGPUTiming\(renderer.getContext\?\.\(\),\{enabled:new URLSearchParams\(location.search\).get\('profile'\)==='1'\}\)/);
 assert.match(runtime,/resources.own\('optional local GPU timing',\(\)=>gpuTiming.dispose\(\)\)/);
 assert.match(runtime,/gpuTiming:gpuTiming.snapshot\(\)/);
 assert.match(runtime,/performanceMonitor.reset\(\);gpuTiming.reset\(\)/);
 const frame=runtime.slice(runtime.indexOf('function frame(time)'));
 assert(frame.indexOf('gpuTiming.poll()')<frame.indexOf('if (skipViewerFrame'));
 assert(frame.indexOf('gpuTiming.poll()')<frame.indexOf('if(time-last<15)'));
});
test('both capture and live render close owned GPU samples even when rendering throws',()=>{
 const blocks=[...runtime.matchAll(/const gpuSample=gpuTiming.begin\(\);\s*try\{(?:applySurfaceSolo\(\);)?composer.render\(\);([^}]*?)\}finally\{if\(gpuSample\)gpuTiming.end\(\);\}/g)];
 assert.equal(blocks.length,2);
 for(const [block] of blocks)for(const begin of [true,false])for(const throws of [true,false]){
  let ends=0,renderCalls=0;
  const context={applySurfaceSolo(){},gpuTiming:{begin:()=>begin,end:()=>ends++},composer:{render(){renderCalls++;if(throws)throw Error('render failure');}},renderedFrames:0,dirty:true,premiumRequested:true,premiumActive:()=>true,presentationGate:{rendered(){}}};
  if(throws)assert.throws(()=>vm.runInNewContext(block,context),/render failure/);else vm.runInNewContext(block,context);
  assert.equal(renderCalls,1);assert.equal(ends,Number(begin));
 }
});
